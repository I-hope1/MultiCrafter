
// 要想调用多合工厂，必须有这个
this.window = this;
require('多合工厂');

// 这是一个案例
newCrafter('案例', /* 名称 */ prov(() => [
	{
		rdminput: true, /* 输入任一 */
		input: [[Items.copper, /* 物品/液体 */ 2 /* 数量 */], [Items.lead, 2], Items.titanium /* 直接物品/液体, 数量为1 */], /*输入 */
		rdmoutput: false, /* 输出任一 */
		output: [ItemsAndLiquids['isand'] /* 用字符串来搜索Content，i开头为物品，l开头为液体 */], /* 输出 */
		extraOutput: [[Items.scrap, 1, .5 /* 概率(默认0.5) */]]
	},
	{
		rdminput: false,
		input: [[Vars.content.getByName(ContentType.item, 'coal'), 1], [Liquids.water, 2]],
		rdmoutput: false,
		output: [[Liquids.oil, 2]]
	}
]), /* 合成表 */ false, /* random */ 30, /* 工作时间 */ 10 /*消耗电量 */).research = 'arc';

// newCrafter('test', 10, 10).plan([Item.copper], [], [])